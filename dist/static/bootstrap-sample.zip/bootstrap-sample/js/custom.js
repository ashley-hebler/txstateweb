// 1. Your first JS function


// 2. ToggleClass
var button = document.getElementById('showBtn');
var thumb = document.getElementById('thumbDiv');
var className = 'open';
button.addEventListener('click', addClass);

function addClass() {
	thumb.classList.add('open');
}
// Vanilla JS
function toggleClass() {
	if (thumb.classList.contains('open')) {
		thumb.classList.remove('open');
	} else {
		thumb.classList.add('open');
	}
}
// using jQuery instead
function jqToggleClass() {
	$('#thumbDiv').toggleClass('open')
}

// 3. Parallax Scrolling
$(document).ready(function() {
	// create variables
	var $fwindow = $(window);
	var scrollTop = window.pageYOffset || document.documentElement.scrollTop;
	// on window scroll event
	$fwindow.on('scroll resize', function() {
		scrollTop = window.pageYOffset || document.documentElement.scrollTop;
	});
	$('div[data-type="background"]').each(function() {
		var $backgroundObj = $(this);
		var bgOffset = parseInt($backgroundObj.offset().top);
		var yPos;
		var coords;
		var speed = ($backgroundObj.data('speed') || 0);
		$fwindow.on('scroll resize', function() {
			yPos = -((scrollTop - bgOffset) / speed);
			coords = '50% ' + yPos + 'px';
			$backgroundObj.css({ backgroundPosition: coords });
		});
	}); // end section function
	// triggers winodw scroll for refresh
	$fwindow.trigger('scroll');
}); // close out script
